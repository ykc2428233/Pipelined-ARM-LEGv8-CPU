Compile order:
xorgate.vhd half_adder.vhd full_adder.vhd adder64.vhd add.vhd mux5.vhd mux64.vhd mux64_3to1.vhd muxcontrol.vhd alu.vhd alucontrol.vhd cpucontrol.vhd shiftleft2.vhd signextend.vhd pc.vhd forwarding.vhd hazarddetction.vhd equalzero.vhd reg_IFID.vhd reg_IDEX.vhd reg_EXMEM.vhd reg_MEMWB.vhd registers.vhd lab5_dmem.vhd lab5_imem.vhd pipelinedcpu2.vhd pipelinedcpu2_tb.vhd
